import React, { useState,useEffect,useReducer} from 'react';

import Card from '../UI/Card/Card';
import classes from './Login.module.css';
import Button from '../UI/Button/Button';

const emailreducer = (state,actions) =>{

  if(actions.type === "USER_INPUT")
  {
    return {value:actions.val,isvalid:actions.val.includes('@')};
  }
  if(actions.type === "INPUT_BLUR")
  {
    return {value:state.value,isvalid:state.value.includes('@')};
  }
  return {value:'',isvalid:false}
}


const passwordReducer = (state,actions) => {

  if(actions.type === "USER_INPUT")
  {
    return {value:actions.val,isvalid:actions.val.trim().length > 6};
  }
  if(actions.type === "INPUT_BLUR")
  {
    return {value:state.value,isvalid:state.value.trim().length > 6};
  }
  return {value:'',isvalid:false}

}


const Login = (props) => {
  // const [enteredEmail, setEnteredEmail] = useState('');
  // const [emailIsValid, setEmailIsValid] = useState();
  // const [enteredPassword, setEnteredPassword] = useState('');
  // const [passwordIsValid, setPasswordIsValid] = useState();
  const [formIsValid, setFormIsValid] = useState(false);

  const [emailState,dispathEmail] = useReducer(emailreducer,{value:'',isvalid:false})

  const [passwordState,dispathpassword] = useReducer(passwordReducer,{value:'',isvalid:false})

    const {isvalid:emailValid} = emailState;
    const {isvalid:passwordValid} = passwordState;

    useEffect(()=>{
      const identifier = setTimeout(() => {
        console.log("formvalidity check")
       setFormIsValid(
        emailValid && passwordValid
        );
  }, 500);
     
  return ()=>{

    console.log('cleanup');
    clearTimeout(identifier);
  }

    },[emailValid,passwordValid])

  const emailChangeHandler = (event) => {
    //setEnteredEmail(event.target.value);
    dispathEmail({type:'USER_INPUT',val:event.target.value})
    setFormIsValid(
      event.target.value.includes('@') && passwordState.isvalid
    );
  };

  const passwordChangeHandler = (event) => {
   // setEnteredPassword(event.target.value);
   dispathpassword({type:'USER_INPUT',val:event.target.value})
    setFormIsValid(
      emailState.isvalid && event.target.value.trim().length > 6 
    );
  };

  const validateEmailHandler = () => {
    dispathEmail({type:'INPUT_BLUR'})
    //setEmailIsValid(emailState.isvalid);
  };

  const validatePasswordHandler = () => {
   // setPasswordIsValid(enteredPassword.trim().length > 6);
   dispathpassword({type:'INPUT_BLUR'})
  };

  const submitHandler = (event) => {
    event.preventDefault();
    props.onLogin(emailState.value, passwordState.value);
  };

  return (
    <Card className={classes.login}>
      <form onSubmit={submitHandler}>
        <div
          className={`${classes.control} ${
            emailState.isvalid === false ? classes.invalid : ''
          }`}
        >
          <label htmlFor="email">E-Mail</label>
          <input
            type="email"
            id="email"
            value={emailState.value}
            onChange={emailChangeHandler}
            onBlur={validateEmailHandler}
          />
        </div>
        <div
          className={`${classes.control} ${
            passwordState.isvalid === false ? classes.invalid : ''
          }`}
        >
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={passwordState.value}
            onChange={passwordChangeHandler}
            onBlur={validatePasswordHandler}
          />
        </div>
        <div className={classes.actions}>
          <Button type="submit" className={classes.btn} disabled={!formIsValid}>
            Login
          </Button>
        </div>
      </form>
    </Card>
  );
};

export default Login;
