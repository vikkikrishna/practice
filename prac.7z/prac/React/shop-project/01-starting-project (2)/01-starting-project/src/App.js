import { Fragment,useState } from "react";
import CartProvider from "./store/CartProvider";

import Header from "./components/Layout/Header";
import Meals from "./components/Meals/Meals";
import Cart from "./components/Cart/Cart";
function App() {

 const [cartIsShown,setCartIsShown] = useState(false);


 const showCartHanlder  =() =>{
  setCartIsShown(true)
 }


 
 const hideCartHanlder  =() =>{
  setCartIsShown(false)
 }

  return (
    <CartProvider>

     {cartIsShown && <Cart onClose= {hideCartHanlder} />} 

      <Header onShowCart  = {showCartHanlder}></Header>
      <Meals></Meals>
    </CartProvider>
  );
}

export default App;
