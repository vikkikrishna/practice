import { useReducer } from "react";

import CartContext from "./cart-content";

const defaultCartState = {
    items:[],
    totalAmount:0,
   
}

const cartReducer = (state,actions) => {

    if(actions.type === 'ADD'){
            const updatedItems = state.items.concat(actions.item);
            const UpdatedTotalAmount  = state.totalAmount +  actions.item.price * actions.item.amount;

            return {
                items:updatedItems,
                totalAmount:UpdatedTotalAmount

            }
    }
    

    if(actions.type === 'REMOVE'){

    }

    return defaultCartState;
}

const CartProvider = props =>{

        const  [cartState,diapatchCartAction] = useReducer(cartReducer,defaultCartState)

    const addItemHandler = (item) =>{

        diapatchCartAction({type:'ADD',item:item})
    }

    const removeItemHandler = (id) =>{
        diapatchCartAction({type:'REMOVE',id:id})
    }

    const cartContext = {
        items :cartState.items,
        totalAmount:cartState.totalAmount,
        additem :addItemHandler,
        removeItem :removeItemHandler
        
    }

        return <CartContext.Provider value = {cartContext}>

            {props.children}
        </CartContext.Provider>
}


export default CartProvider;