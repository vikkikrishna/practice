import React,{Fragment} from "react";
import { useContext } from "react";
import CartContext from "../../store/cart-content";
import CartIcon from "../Cart/CartIcon";
import classes from './HeaderCardButton.module.css'

const HeaderCartButton = props =>{

 const cartctx = useContext(CartContext);
    const numberCartItems = cartctx.items.reduce ((currenNumber,item) => { return currenNumber + item.amount },0)
    return <button type="" className={classes.button } onClick = {props.onClick}>
        <span className={classes.icon}>
        <CartIcon></CartIcon>
        </span>
        <span>Your Cart</span>
        <span className={classes.badge}>
           {numberCartItems}
        </span>
    </button>;
}

export default HeaderCartButton;