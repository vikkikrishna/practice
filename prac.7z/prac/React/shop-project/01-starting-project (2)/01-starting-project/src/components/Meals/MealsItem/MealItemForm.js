import classes from './MealItemForm.module.css'
    import Input from '../../UI/Input';
import React,{ useRef ,useState,useEffect} from 'react';
    
const MealItemForm  = props => {

    const [height, setHeight] = useState(0);
    const [amountIsValid,setAmountValid] = useState(true);


    const amountInputRef = useRef(null);
    console.log("amountInputRef" + amountInputRef.current);

    useEffect(() => {
        const el2 = amountInputRef.current;
        console.log('amountInputRef123' +el2); // 👈️ element here
      }, [amountInputRef]);

    const submitHandler = event  =>{
        event.preventDefault();

        const enteramount = amountInputRef.current.value;
        const enterAmountNumber = +enteramount;

        if(enterAmountNumber.trim().length === 0 || enterAmountNumber < 0    ||  enterAmountNumber > 5 ){

            setAmountValid(false);
             return;
        }
        props.onAddToCart(enterAmountNumber);

    };

    return <form className={classes.form} onSubmit ={submitHandler}>
        <Input label="amount" input ={{
            ref :{amountInputRef},
            id:'amount',
            type:'input',
            min:'1',
            max:'5',
            step:'1',
            defaultValue:'2'
        }} />
        <button type=""> + Add</button>
    </form>
}


export default MealItemForm;