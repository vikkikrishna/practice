import React,{useState,Fragment} from 'react';
import AddUser from './Components/Users/AddUser';

import UsersList from './Components/Users/UserList';
function App() {

  const [userList,setUsetList] = useState([]);

  const addUsersHandler = (uName,uAge)=>{
    setUsetList((prevuserlist) =>{
      return[...prevuserlist,{name:uName , age:uAge,id:Math.random().toString()}]
    })
  }
  return (
    <Fragment>
        <AddUser onAddUser={addUsersHandler} />
        <UsersList users={userList} />
    </Fragment>
  );
}

export default App;
