import React,{useState,useRef} from "react";

import Card from "../UI/Card";
 import Button from "../UI/Button";
import styles from './AddUser.module.css'
import ErrorModel from "../UI/ErrorModel";
import Wrapper from "../Helpers/Wrapper";

const AddUser = (props) => {

   const nameinputref = useRef();
   const ageinputref = useRef();

   const [enteredUsername,setUserName] = useState('');
   const [enteredAge,setAge] = useState('');

  const [error,setError] = useState();
    
    const addUserHandler = (event) => {
        event.preventDefault();
        if(enteredUsername.trim().length === 0 || enteredAge.trim().length === 0 ){

            setError({
                title:'Valid input',
                message:"please enter the valid name and age (non -empty values)"
            })
            return;
        }

        if(+enteredAge < 1){
           
            setError({
                title:'Valid input',
                message:"please enter the valid age (>0)"
            })
            return;
        }
        console.log(enteredUsername,enteredAge);
        props.onAddUser(enteredUsername,enteredAge)
        setUserName('');
        setAge('');
    }

   
     const usernameChangeHandler = (event) =>{
        setUserName(event.target.value)
     }

     const ageChangeHandler = (event) =>{
        setAge(event.target.value)
    }

    const errorHandler = ()=>{
        setError(null);
    }
    return(
        <Wrapper>
            {error && <ErrorModel title={error.title} message={error.message} onConfirm = {errorHandler}/> } 
        <Card className={styles.input}>
        <form onSubmit={addUserHandler}>
        <label htmlFor="username"> UserName </label> 
        <input id="username" value={enteredUsername}  type="text" onChange={usernameChangeHandler} ref ={nameinputref} />
        <label htmlFor="age"> Age </label> 
        <input id="age"  value={enteredAge} type="number"  onChange={ageChangeHandler} ref ={ageinputref} />
        <Button type="submit"> Add user </Button>
        </form>
        </Card>
        </Wrapper>

       
    );
};

export default AddUser;