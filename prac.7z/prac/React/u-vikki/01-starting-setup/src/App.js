import Expenseitem from "./components/Expenseitem";

function App() {
  
  const expenses = [
    {title:'car insurance1',amount:parseInt(562.2),data:new Date(2021,2,24)},
  {
    title:'car insurance2',amount:parseInt(562.2),data:new Date(2021,2,24)
  },
  {
    title:'car insurance3',amount:parseInt(562.2),data:new Date(2021,2,24)
  },
  {
    title:'car insurance4',amount:parseInt(562.2),data:new Date(2021,2,24)
  },

]
  return (
    <div>
      <h2>Let's get started!</h2>
      <Expenseitem title = {expenses[0].title} amount = {expenses[0].amount} date = {expenses[0].data}  > </Expenseitem>
      <Expenseitem title = {expenses[1].title} amount = {expenses[1].amount} date = {expenses[1].data}  > </Expenseitem>
      <Expenseitem title = {expenses[2].title} amount = {expenses[2].amount} date = {expenses[2].data}  > </Expenseitem>
      <Expenseitem title = {expenses[3].title} amount = {expenses[3].amount} date = {expenses[3].data}  > </Expenseitem>
    </div>
  );
}

export default App;
