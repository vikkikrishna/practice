import './Expenseitem.css'
import Card from './Card';
import ExpenseDate from './ExpenseDate';
function Expenseitem(pros) {
    const month  = pros.date.toLocaleString('en-US',{month:'long'});
    const day =  pros.date.toLocaleString('en-US',{day:'2-digit'});
    const year = pros.date.getFullYear();
    return (<Card className="expense-item"> <div>
            <ExpenseDate date={pros.date} />
        </div>  <div className="expense-item__description"> <h2>{pros.title}</h2>
        <div className="expense-item__price">${pros.amount}</div> </div>
    </Card>)
}

export default Expenseitem